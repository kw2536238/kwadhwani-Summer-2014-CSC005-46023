/* 
* File:   main.cpp
* Author: Krishen Wadhwani
* Purpose: Savitch_8thEd_Chap1_Prob6
* Created on June 24, 2014, 1:30 PM
*/

//System library

#include <iostream> 

using namespace std;

//User Defined Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here

int main (int argc, char** argv ) 
{
   //Output Everything
    cout << "****************************************************";
    cout << "\n\n";
    cout << "         C C C            S S S S          !!         \n";
    cout << "       C       C         S                 !!         \n";
    cout << "      C                 S                  !!         \n";
    cout << "     C                   S                 !!         \n";
    cout << "     C                    S S S S          !!         \n";
    cout << "     C                           S         !!         \n";
    cout << "      C                           S        !!         \n";
    cout << "       C                         S                    \n";
    cout << "         C C C            S S S S          00         \n";
    cout << "\n";
    cout << "****************************************************";
    cout << "\n";
    cout << "          Computer Science is Cool Stuff!!!\n";
   return 0;
}                                
