/* 
* File:   main.cpp
* Author: Krishen Wadhwani
* Purpose: First Program
* Created on June 23, 2014, 12:18 PM
*/
//System Level Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) 
{

    //Declare and Initialize All Variables
    char numb;
    
    //Enter the Input character
    cout << "Enter in a character: ";
    cin >> numb;
    
    //First Line
    cout << "\n     ";
    
    //Second Line
    cout << numb;
    cout << " ";
    cout << numb;
    cout << " ";
    cout << numb;
    cout << " ";
    
    //Third Line
    cout << "\n    ";
    cout << numb;
    cout << "    ";
    cout << numb;
    
    //Body
    cout << "\n   ";
    cout << numb;
    cout << "\n   ";
    cout << numb;
    cout << "\n   ";
    cout << numb;
    cout << "\n   ";
    cout << numb;
    cout << "\n   ";
    cout << numb;
    
    //5th Line
    cout << "\n    ";
    cout << numb;
    cout << "    ";
    cout << numb;
    
    //Last Line
    cout << "\n     ";
    cout << numb;
    cout << " ";
    cout << numb;
    cout << " ";
    cout << numb;
    cout << "\n";
    
   return 0;
}