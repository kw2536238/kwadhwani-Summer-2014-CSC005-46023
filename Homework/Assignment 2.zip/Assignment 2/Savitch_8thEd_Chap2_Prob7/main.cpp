/* 
 * File:   main.cpp
 * Author: Krishen Wadhwani
 * Purpose: Savitch_8thEd_Chap2_Prob7
 * Created on July 1, 2014, 11:34 PM
 */

#include <iostream>

using namespace std;


int main(int argc, char** argv) {

    return 0;
}

